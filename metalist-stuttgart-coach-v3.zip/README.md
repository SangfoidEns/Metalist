# МЕТАЛІСТ ШТУТГАРТ — Coaching System

Professional football **Tactical Board + Training Planner** for coaches.

**Stack:** Vite · Vanilla JS (ES modules) · Canvas 2D · IndexedDB · Telegram WebApp SDK

## Features

- **Tactical Board (Canvas)** — 60fps, unlimited objects
- **Immediate touch drag** — finger attaches to player instantly, any distance, any direction
- **Pointer Events** — mouse, touch, stylus, Apple Pencil, S Pen
- **Fullscreen / Board Only** — Browser Fullscreen API + Telegram `requestFullscreen`
- **Zoom / Pan** — pinch, wheel, buttons
- **Zones** — rect, circle, polygon, freehand
- **Arrows** — pass, run, dribble, shot, press
- **Formations** — 4-3-3, 4-2-3-1, 4-4-2, 3-5-2 + custom
- **Keyframe animation** — add keyframes, play/pause/stop
- **Scenes** — unlimited scenes per project
- **Training sessions** — linked to scenes
- **Players roster**
- **Undo/Redo** (100 steps soft buffer)
- **Autosave** (IndexedDB + localStorage fallback)
- **Export JSON**
- **Telegram Mini App** ready

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Build

```bash
npm run build
npm run preview
```

Output: `dist/`

## GitHub Pages deploy

1. Push to `main`
2. GitHub Actions runs `.github/workflows/deploy.yml`
3. Enable **Settings → Pages → Source: GitHub Actions**
4. App is live at `https://<user>.github.io/<repo>/`

## Telegram Mini App

1. Deploy to HTTPS (GitHub Pages)
2. Create bot via [@BotFather](https://t.me/BotFather)
3. `/newapp` → set Web App URL to your Pages URL
4. Open from bot menu or direct link:
   `https://t.me/<bot>/<app>`

Bot token stays **only on the server** (never in frontend).  
Use `.env` for any server-side secrets.

### Telegram features used

| API | Purpose |
|-----|---------|
| `WebApp.ready()` / `expand()` | Init |
| `requestFullscreen()` / `exitFullscreen()` | Fullscreen |
| `themeParams` | Theme sync |
| `safeAreaInset` | Notch / home bar |
| `lockOrientation('landscape')` | Board mode |
| `viewportChanged` | Resize |

## Architecture

```
src/
  board/TacticalBoardEngine.js   # Canvas engine, drag, draw, anim
  telegram/TelegramManager.js    # Mini App SDK
  storage/StorageManager.js      # IndexedDB + LS
  state/store.js                 # App state
  main.js                        # UI wiring
  styles.css
```

### Drag algorithm (no distance limit)

```
pointerdown on player
  → hit-test (48px radius)
  → setPointerCapture(pointerId)
  → store offset = worldPos - playerPos
pointermove
  → player.x = worldPos.x - offset.x   // unlimited
  → player.y = worldPos.y - offset.y
  → render frame only (no save, no UI rebuild)
pointerup
  → releaseCapture
  → pushHistory + debounced autosave
```

World coordinates are always **normalized 0..1**. Camera zoom/pan is render-only.

## Keyboard

| Key | Action |
|-----|--------|
| F | Board Only / Fullscreen |
| Esc | Exit Board Only |
| Space | Play / Pause |
| Ctrl+Z / Y | Undo / Redo |
| Delete | Delete selected |

## License

Private — МЕТАЛІСТ ШТУТГАРТ coaching use.
